﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string pass = txtPass.Text;

            string query = "select* from UserInfo where Email='" + email + "' and [Password]='" + pass + "'";
            // MessageBox.Show(query);

            DataTable result = DataConnect.GetData(query);
            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            if (result.Rows.Count != 1)
            {
                MessageBox.Show("Ivalid Email or Password");
                return;
            }
            // MessageBox.Show("Success");

            string utype = result.Rows[0]["User Type"].ToString();
            string name = result.Rows[0]["Name"].ToString();
            MessageBox.Show("Welcome " + name);

            //MessageBox.Show(utype);

            if (utype == "Admin")
            {
                AdminForm af = new AdminForm();
                af.Show();
                this.Hide();
            }

        }
    }
}
