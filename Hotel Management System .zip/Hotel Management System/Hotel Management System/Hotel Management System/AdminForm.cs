﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();

        }

        private void manageEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmployeeForm ef = new EmployeeForm();
            ef.Show();
        }

        private void manageCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerForm cf = new CustomerForm();
            cf.Show();

        }

        private void manageRoomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RoomForm rf = new RoomForm();
            rf.Show();
        }

        private void reservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RoomRentForm rrf = new RoomRentForm();  
            rrf.Show();
        }
    }
}
