﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }
        private void LoadData()
        {
            var query = "select * from Customer ";
            DataTable result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            dgvCustomer.AutoGenerateColumns = false;
            dgvCustomer.DataSource = result;
            dgvCustomer.Refresh();
            dgvCustomer.ClearSelection();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.LoadData();
            this.NewData();
        }

        private void dgvCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //  MessageBox.Show(e.RowIndex + "");

            if (e.RowIndex >= 0)
            {
                string id = dgvCustomer.Rows[e.RowIndex].Cells[0].Value.ToString();
                // MessageBox.Show(id);
                this.LoadSingleData(id);
            }

        }
        private void LoadSingleData(string id)
        {
            var query = "select * from Customer where id = " + id + "";
            var result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            txtID.Text = result.Rows[0]["Id"].ToString();
            txtName.Text = result.Rows[0]["Name"].ToString();
            txtAge.Text = result.Rows[0]["Age"].ToString();
            txtPhoneNumber.Text = result.Rows[0]["Phone Number"].ToString();
            rtxtAddress.Text = result.Rows[0]["Address"].ToString();

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            this.NewData();
        }
        private void NewData()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtAge.Text = "";
            txtPhoneNumber.Text = "";
            rtxtAddress.Text = "";
            dgvCustomer.ClearSelection();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.DeleteData();
        }
        private void DeleteData()
        {

            string id = txtID.Text;

            if (id == "")
            {
                MessageBox.Show("Please select a row first");
                return;

            }
            var userResult = MessageBox.Show("Are You Sure?", "Confirmation", MessageBoxButtons.YesNo);
            if (userResult == DialogResult.No)
            {
                return;
            }
            var query = "delete from Customer where id = " + id + "";
            var result = DataConnect.ExecuteQuery(query);

            if (result == false)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            MessageBox.Show("Deleted");
            this.LoadData();
            this.NewData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.SaveData();
        }
        private void SaveData()
        {
            string id = txtID.Text;
            string name = txtName.Text;
            string age = txtAge.Text;
            string phone_number = txtPhoneNumber.Text;
            string address = rtxtAddress.Text;

            if (txtID.Text == "")
            {
                // MessageBox.Show("Insert");

                var query = "insert into Customer ([Name],[Age],[Phone Number],[Address]) output inserted.Id values ('" + name + "','"+age+"', '" + phone_number + "','" + address + "')";
                var result = DataConnect.GetData(query);

                if (result == null)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Added");
                txtID.Text = result.Rows[0]["Id"].ToString();


            }
            else
            {
                // MessageBox.Show("Update");

                var query = "update Customer set [Name] = '" + name + "', [Address] = '" + address + "' where id = " + id + "";
                var result = DataConnect.ExecuteQuery(query);

                if (result == false)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Updated");


            }
            this.LoadData();

            for (int i = 0; i < dgvCustomer.Rows.Count; i++)
            {
                string selectedId = dgvCustomer.Rows[i].Cells[0].Value.ToString();
                if (selectedId == txtID.Text)
                {
                    dgvCustomer.Rows[i].Selected = true;
                    break;
                }


            }

        } 
    } 
}
