﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Hotel_Management_System
{
    public partial class RoomForm : Form
    {
        public RoomForm()
        {
            InitializeComponent();
        }

        private void RoomForm_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }
        private void LoadData()
        {
            var query = "select * from Room";
            DataTable result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            dgvRoom.AutoGenerateColumns = false;
            dgvRoom.DataSource = result;
            dgvRoom.Refresh();
            dgvRoom.ClearSelection();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.LoadData();
            this.NewData();
        }

        private void dgvRoom_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //  MessageBox.Show(e.RowIndex + "");

            if (e.RowIndex >= 0)
            {
                string id = dgvRoom.Rows[e.RowIndex].Cells[0].Value.ToString();
                // MessageBox.Show(id);
                this.LoadSingleData(id);
            }

        }
        private void LoadSingleData(string id)
        {
            var query = "select * from Room where id = " + id + "";
            var result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            txtID.Text = result.Rows[0]["Id"].ToString();
            txtRoomType.Text = result.Rows[0]["RoomType"].ToString();



        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            this.NewData();
        }
        private void NewData()
        {
            txtID.Text = "";
            txtRoomType.Text = "";

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.DeleteData();
        }
        private void DeleteData()
        {

            string id = txtID.Text;

            if (id == "")
            {
                MessageBox.Show("Please select a row first");
                return;

            }
            var userResult = MessageBox.Show("Are You Sure?", "Confirmation", MessageBoxButtons.YesNo);
            if (userResult == DialogResult.No)
            {
                return;
            }
            var query = "delete from Room where id = " + id + "";
            var result = DataConnect.ExecuteQuery(query);

            if (result == false)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            MessageBox.Show("Deleted");
            this.LoadData();
            this.NewData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.SaveData();
        }
        private void SaveData()
        {
            string id = txtID.Text;
            string roomtype = txtRoomType.Text;


            if (txtID.Text == "")
            {
                // MessageBox.Show("Insert");

                var query = "insert into Room ([RoomType]) output inserted.Id values ('" + roomtype + "')";
                var result = DataConnect.GetData(query);

                if (result == null)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Added");
                txtID.Text = result.Rows[0]["Id"].ToString();


            }
            else
            {
                // MessageBox.Show("Update");

                var query = "update Room set [RoomType] = '" + roomtype + "' where id = " + id + "";
                var result = DataConnect.ExecuteQuery(query);

                if (result == false)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Updated");


            }
            this.LoadData();

            for (int i = 0; i < dgvRoom.Rows.Count; i++)
            {
                string selectedId = dgvRoom.Rows[i].Cells[0].Value.ToString();
                if (selectedId == txtID.Text)
                {
                    dgvRoom.Rows[i].Selected = true;
                    break;
                }


            }

        }
    }
}


