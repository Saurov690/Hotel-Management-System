﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hotel_Management_System
{
    class DataConnect
    {
        static string _connectionstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""E:\Hotel Management System\HMS.mdf"";Integrated Security=True;Connect Timeout=30";
        public static DataTable GetData(string query)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionstring);
                con.Open();

                SqlCommand cmd = new SqlCommand(query, con);

                DataSet ds = new DataSet();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);

                DataTable dt = ds.Tables[0];
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public static bool ExecuteQuery(string query)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionstring);
                con.Open();

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }


        }
    }
}