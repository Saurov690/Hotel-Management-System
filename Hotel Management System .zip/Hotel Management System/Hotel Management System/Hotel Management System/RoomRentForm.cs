﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class RoomRentForm : Form
    {
        public RoomRentForm()
        {
            InitializeComponent();
        }

        private void RoomRentForm_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }
            private void LoadData()
            {
                var query = "select RoomRent.Id,Customer.[Name],Room.RoomType,RoomRent.Amount from  RoomRent inner join Customer on Customer.Id = RoomRent.CustomerID inner join Room on Room.Id = RoomRent.RoomID";
                DataTable result = DataConnect.GetData(query);

                if (result == null)
                {
                    MessageBox.Show("Something Went Wrong With RoomRent");
                    return;
                }
                dgvRoomRent.AutoGenerateColumns = false;
                dgvRoomRent.DataSource = result;
                dgvRoomRent.Refresh();
                dgvRoomRent.ClearSelection();

            var queryCustomer = "select * from Customer";
            DataTable resultCustomer = DataConnect.GetData(queryCustomer);

            if (resultCustomer == null)
            {
                MessageBox.Show("Something Went Wrong with Customer");
                return;
            }

            var queryRoom = "select * from Room";
            DataTable resultRoom = DataConnect.GetData(queryRoom);

            if (resultRoom == null)
            {
                MessageBox.Show("Something Went Wrong with Room");
                return;
            }

            cmbRoomType.DataSource = resultRoom;
            cmbRoomType.DisplayMember = "RoomType";
            cmbRoomType.ValueMember = "Id";


        }

        private void dgvRoomRent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //  MessageBox.Show(e.RowIndex + "");

            if (e.RowIndex >= 0)
            {
                string id = dgvRoomRent.Rows[e.RowIndex].Cells[0].Value.ToString();
                // MessageBox.Show(id);
                this.LoadSingleData(id);
            }

        }
        private void LoadSingleData(string id)
        {
            var query = "select * from RoomRent where id = " + id + "";
            var result = DataConnect.GetData(query);

            if (result == null)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            txtID.Text = result.Rows[0]["Id"].ToString();
            //txtName.Text = result.Rows[0]["Name"].ToString();   
            cmbRoomType.SelectedValue = result.Rows[0]["RoomID"].ToString();
            txtAmount.Text = result.Rows[0]["Amount"].ToString();

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            this.NewData();
        }
        private void NewData()
        {
            txtID.Text = "";
            txtName.Text = "";
            cmbRoomType.SelectedValue = " -1 ";
            txtAmount.Text = "";
            dgvRoomRent.ClearSelection();
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.DeleteData();
        }

        private void DeleteData()
        {

            string id = txtID.Text;

            if (id == "")
            {
                MessageBox.Show("Please select a row first");
                return;

            }
            var userResult = MessageBox.Show("Are You Sure?", "Confirmation", MessageBoxButtons.YesNo);
            if (userResult == DialogResult.No)
            {
                return;
            }
            var query = "delete from RoomRent where id = " + id + "";
            var result = DataConnect.ExecuteQuery(query);

            if (result == false)
            {
                MessageBox.Show("Something Went Wrong");
                return;
            }
            MessageBox.Show("Deleted");
            this.LoadData();
            this.NewData();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.LoadData();
            this.NewData();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.SaveData();
        }
        private void SaveData()
        {
            string id = txtID.Text;
            string name = txtName.Text;
            string roomtype = cmbRoomType.SelectedValue.ToString();
            string amount = txtAmount.Text;


            if (txtID.Text == "")
            {
                // MessageBox.Show("Insert");

                var query = "insert into RoomRent (CustomerID,RoomID,Amount) output inserted.Id values ('" + name + "','" + roomtype + "','" + amount + "')";
                var result = DataConnect.GetData(query);

                if (result == null)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Added");
                txtID.Text = result.Rows[0]["Id"].ToString();


            }
            else
            {
                // MessageBox.Show("Update");

                var query = "update RoomRent set CustomerID='" + name + "',RoomID='" + roomtype + "',Amount='" + amount + "' where Id=' " + id + "'";
                var result = DataConnect.ExecuteQuery(query);

                if (result == false)
                {
                    MessageBox.Show("Something Went Wrong");
                    return;
                }
                MessageBox.Show("Information Updated");


            }
            this.LoadData();

             for (int i = 0; i < dgvRoomRent.Rows.Count; i++)
            {
              string selectedId = dgvRoomRent.Rows[i].Cells[0].Value.ToString();
             if (selectedId == txtID.Text)
            {
              dgvRoomRent.Rows[i].Selected = true;
            break;
            }


             }
        }

    }
}

        



